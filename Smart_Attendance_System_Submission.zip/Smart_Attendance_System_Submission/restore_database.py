import sqlite3
import csv
from pathlib import Path


DATABASE_FILE = Path("data/attendance/attendance.db")
CSV_FILE = Path("data/attendance/attendance_export.csv")


connection = sqlite3.connect(DATABASE_FILE)
cursor = connection.cursor()


# Create users table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        user_id INTEGER PRIMARY KEY,
        name TEXT NOT NULL,
        department TEXT,
        face_encoding BLOB NOT NULL
    )
""")


# Create attendance table
cursor.execute("""
    CREATE TABLE IF NOT EXISTS attendance (
        attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        time TEXT NOT NULL,
        status TEXT NOT NULL,
        UNIQUE(user_id, date),
        FOREIGN KEY (user_id) REFERENCES users(user_id)
    )
""")


# Read CSV and restore data
with open(CSV_FILE, "r", encoding="utf-8") as file:

    reader = csv.DictReader(file)

    for row in reader:

        user_id = int(row["User ID"])
        name = row["Name"]
        department = row["Department"]
        date = row["Date"]
        time = row["Time"]
        status = row["Status"]

        cursor.execute("""
            INSERT OR IGNORE INTO users
            (user_id, name, department, face_encoding)
            VALUES (?, ?, ?, ?)
        """, (
            user_id,
            name,
            department,
            b""
        ))

        cursor.execute("""
            INSERT OR IGNORE INTO attendance
            (attendance_id, user_id, date, time, status)
            VALUES (?, ?, ?, ?, ?)
        """, (
            int(row["Attendance ID"]),
            user_id,
            date,
            time,
            status
        ))


connection.commit()
connection.close()

print("Database restored successfully!")