import sqlite3
import csv
from pathlib import Path


DATABASE_FILE = Path("data/attendance/attendance.db")
CSV_FILE = Path("data/attendance/attendance_export.csv")


def get_attendance_records():
    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            attendance.attendance_id,
            users.user_id,
            users.name,
            users.department,
            attendance.date,
            attendance.time,
            attendance.status
        FROM attendance
        JOIN users
        ON attendance.user_id = users.user_id
        ORDER BY attendance.date DESC, attendance.time DESC
    """)

    records = cursor.fetchall()
    connection.close()

    return records


def show_attendance():
    records = get_attendance_records()

    if not records:
        print("No attendance records found.")
        return

    print("\n========== ATTENDANCE HISTORY ==========\n")

    for record in records:
        attendance_id, user_id, name, department, date, time, status = record

        print(
            f"Attendance ID: {attendance_id} | "
            f"User ID: {user_id} | "
            f"Name: {name} | "
            f"Department: {department} | "
            f"Date: {date} | "
            f"Time: {time} | "
            f"Status: {status}"
        )


def export_to_csv():
    records = get_attendance_records()

    if not records:
        print("No attendance records to export.")
        return

    with open(CSV_FILE, "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)

        writer.writerow([
            "Attendance ID",
            "User ID",
            "Name",
            "Department",
            "Date",
            "Time",
            "Status"
        ])

        writer.writerows(records)

    print(f"\nAttendance exported successfully!")
    print(f"CSV file: {CSV_FILE}")


if __name__ == "__main__":
    show_attendance()
    export_to_csv()