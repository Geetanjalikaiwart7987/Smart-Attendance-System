import cv2
import face_recognition
import sqlite3
import pickle
from datetime import datetime
from pathlib import Path

DATABASE_FILE = Path("data/attendance/attendance.db")


def load_registered_users():
    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("""
        SELECT user_id, name, face_encoding
        FROM users
        WHERE face_encoding != ?
    """, (b"",))

    users = cursor.fetchall()
    connection.close()

    known_ids = []
    known_names = []
    known_encodings = []

    for user_id, name, encoding_data in users:
        try:
            encoding = pickle.loads(encoding_data)

            known_ids.append(user_id)
            known_names.append(name)
            known_encodings.append(encoding)

        except Exception:
            continue

    return known_ids, known_names, known_encodings


def mark_attendance(user_id):
    now = datetime.now()
    date = now.strftime("%Y-%m-%d")
    time = now.strftime("%I:%M:%S %p")

    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("""
        SELECT attendance_id
        FROM attendance
        WHERE user_id = ? AND date = ?
    """, (user_id, date))

    existing = cursor.fetchone()

    if existing:
        connection.close()
        return False

    cursor.execute("""
        INSERT INTO attendance
        (user_id, date, time, status)
        VALUES (?, ?, ?, ?)
    """, (user_id, date, time, "Present"))

    connection.commit()
    connection.close()

    return True


def start_attendance():
    known_ids, known_names, known_encodings = load_registered_users()

    if not known_encodings:
        print("No registered face found.")
        return

    camera = cv2.VideoCapture(0, cv2.CAP_DSHOW)

    if not camera.isOpened():
        print("Error: Could not open webcam.")
        return

    print("Attendance camera started.")
    print("Look at the camera.")
    print("Press Q to quit.")

    while True:
        success, frame = camera.read()

        if not success:
            print("Could not read camera.")
            break

        small_frame = cv2.resize(
            frame,
            (0, 0),
            fx=0.25,
            fy=0.25
        )

        rgb_small_frame = cv2.cvtColor(
            small_frame,
            cv2.COLOR_BGR2RGB
        )

        face_locations = face_recognition.face_locations(
            rgb_small_frame,
            model="hog"
        )

        face_encodings = face_recognition.face_encodings(
            rgb_small_frame,
            face_locations
        )

        for face_encoding, location in zip(
            face_encodings,
            face_locations
        ):

            name = "Unknown"
            user_id = None

            if known_encodings:

                matches = face_recognition.compare_faces(
                    known_encodings,
                    face_encoding,
                    tolerance=0.5
                )

                if True in matches:
                    first_match_index = matches.index(True)

                    user_id = known_ids[first_match_index]
                    name = known_names[first_match_index]

                    if mark_attendance(user_id):
                        print(
                            f"Attendance marked: "
                            f"{user_id} - {name}"
                        )
                    else:
                        print(
                            f"Already marked today: "
                            f"{user_id} - {name}"
                        )

            top, right, bottom, left = location

            top *= 4
            right *= 4
            bottom *= 4
            left *= 4

            cv2.rectangle(
                frame,
                (left, top),
                (right, bottom),
                (0, 255, 0),
                2
            )

            if user_id is not None:
                label = f"{user_id} - {name}"
            else:
                label = "Unknown"

            cv2.putText(
                frame,
                label,
                (left, top - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 255, 0),
                2
            )

        cv2.imshow(
            "Smart Attendance System",
            frame
        )

        key = cv2.waitKey(1) & 0xFF

        if key == ord("q"):
            break

    camera.release()
    cv2.destroyAllWindows()


if __name__ == "__main__":
    start_attendance()