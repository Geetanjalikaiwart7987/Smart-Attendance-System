import cv2
import face_recognition
from pathlib import Path

FACE_DIR = Path("data/faces")
FACE_DIR.mkdir(parents=True, exist_ok=True)


def capture_face(user_id):
    camera = cv2.VideoCapture(0)

    if not camera.isOpened():
        print("Error: Could not open webcam.")
        return False

    print("Webcam started.")
    print("Look at the camera...")
    print("Press 'S' to save the face.")
    print("Press 'Q' to quit.")

    while True:
        success, frame = camera.read()

        if not success:
            print("Error: Could not read camera.")
            break

        # Resize image to make face detection faster
        small_frame = cv2.resize(
            frame,
            (0, 0),
            fx=0.25,
            fy=0.25
        )

        # OpenCV BGR -> RGB
        rgb_small_frame = cv2.cvtColor(
            small_frame,
            cv2.COLOR_BGR2RGB
        )

        # Detect faces on smaller image
        small_face_locations = face_recognition.face_locations(
            rgb_small_frame,
            model="hog"
        )

        # Convert coordinates back to original size
        face_locations = []

        for top, right, bottom, left in small_face_locations:
            face_locations.append((
                top * 4,
                right * 4,
                bottom * 4,
                left * 4
            ))

        # Draw rectangle around face
        for top, right, bottom, left in face_locations:
            cv2.rectangle(
                frame,
                (left, top),
                (right, bottom),
                (0, 255, 0),
                2
            )

        # Display number of detected faces
        cv2.putText(
            frame,
            f"Faces detected: {len(face_locations)}",
            (20, 40),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 0),
            2
        )

        cv2.imshow(
            "Smart Attendance - Face Capture",
            frame
        )

        key = cv2.waitKey(1) & 0xFF

        # Save face
        if key == ord("s"):

            if len(face_locations) == 1:

                file_path = FACE_DIR / f"{user_id}.jpg"

                cv2.imwrite(
                    str(file_path),
                    frame
                )

                print(f"Face image saved: {file_path}")

                camera.release()
                cv2.destroyAllWindows()

                return True

            elif len(face_locations) == 0:
                print("No face detected.")

            else:
                print(
                    "Multiple faces detected. "
                    "Only one person should be in front of camera."
                )

        # Quit
        elif key == ord("q"):
            print("Face capture cancelled.")
            break

    camera.release()
    cv2.destroyAllWindows()

    return False


if __name__ == "__main__":

    user_id = input("Enter User ID: ")

    if capture_face(user_id):
        print("Face capture completed successfully!")
    else:
        print("Face capture failed.")