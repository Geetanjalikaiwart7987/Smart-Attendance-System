import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import sqlite3
import subprocess
import sys
from datetime import datetime
from pathlib import Path
import csv
import cv2
import face_recognition
import pickle

DATABASE_FILE = Path("data/attendance/attendance.db")
CSV_FILE = Path("data/attendance/attendance_export.csv")
FACE_DIR = Path("data/faces")


def setup_database():
    DATABASE_FILE.parent.mkdir(parents=True, exist_ok=True)
    FACE_DIR.mkdir(parents=True, exist_ok=True)

    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            department TEXT,
            face_encoding BLOB NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            status TEXT NOT NULL,
            UNIQUE(user_id, date),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    connection.commit()
    connection.close()


def get_dashboard_data():
    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("SELECT COUNT(*) FROM users")
    total_users = cursor.fetchone()[0]

    today = datetime.now().strftime("%Y-%m-%d")

    cursor.execute(
        "SELECT COUNT(*) FROM attendance WHERE date = ?",
        (today,)
    )
    present_today = cursor.fetchone()[0]

    absent = max(total_users - present_today, 0)

    percentage = (
        present_today / total_users * 100
        if total_users > 0 else 0
    )

    connection.close()

    return total_users, present_today, absent, percentage


def register_user():
    window = tk.Toplevel(root)
    window.title("Register User")
    window.geometry("420x400")
    window.resizable(False, False)

    tk.Label(
        window,
        text="REGISTER NEW USER",
        font=("Arial", 18, "bold")
    ).pack(pady=20)

    tk.Label(window, text="User ID").pack()
    user_id_entry = tk.Entry(window, width=30)
    user_id_entry.pack(pady=7)

    tk.Label(window, text="Name").pack()
    name_entry = tk.Entry(window, width=30)
    name_entry.pack(pady=7)

    tk.Label(window, text="Department").pack()
    department_entry = tk.Entry(window, width=30)
    department_entry.pack(pady=7)

    def save_user():
        user_id = user_id_entry.get().strip()
        name = name_entry.get().strip()
        department = department_entry.get().strip()

        if not user_id or not name:
            messagebox.showwarning(
                "Missing Information",
                "User ID and Name are required."
            )
            return

        try:
            user_id = int(user_id)
        except ValueError:
            messagebox.showerror(
                "Invalid User ID",
                "User ID must be a number."
            )
            return

        connection = sqlite3.connect(DATABASE_FILE)
        cursor = connection.cursor()

        cursor.execute(
            "SELECT user_id FROM users WHERE user_id = ?",
            (user_id,)
        )

        existing = cursor.fetchone()

        if existing:
            cursor.execute("""
                UPDATE users
                SET name = ?, department = ?
                WHERE user_id = ?
            """, (name, department, user_id))

        else:
            cursor.execute("""
                INSERT INTO users
                (user_id, name, department, face_encoding)
                VALUES (?, ?, ?, ?)
            """, (user_id, name, department, b""))

        connection.commit()
        connection.close()

        messagebox.showinfo(
            "Success",
            "User saved successfully!"
        )

        window.destroy()
        refresh_dashboard()

    tk.Button(
        window,
        text="SAVE USER",
        command=save_user,
        width=22,
        height=2
    ).pack(pady=25)


def capture_face():
    user_id = simpledialog.askinteger(
        "Capture Face",
        "Enter User ID:"
    )

    if user_id is None:
        return

    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute(
        "SELECT name FROM users WHERE user_id = ?",
        (user_id,)
    )

    user = cursor.fetchone()
    connection.close()

    if user is None:
        messagebox.showerror(
            "User Not Found",
            "Please register this user first."
        )
        return

    name = user[0]

    camera = cv2.VideoCapture(0)

    if not camera.isOpened():
        messagebox.showerror(
            "Camera Error",
            "Could not open webcam."
        )
        return

    while True:
        success, frame = camera.read()

        if not success:
            break

        cv2.putText(
            frame,
            f"User: {name}  ID: {user_id}",
            (20, 35),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.8,
            (0, 255, 0),
            2
        )

        cv2.putText(
            frame,
            "Press S to save | Q to quit",
            (20, 70),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (0, 255, 255),
            2
        )

        cv2.imshow("Face Capture", frame)

        key = cv2.waitKey(1) & 0xFF

        if key == ord("s"):
            rgb_frame = cv2.cvtColor(
                frame,
                cv2.COLOR_BGR2RGB
            )

            locations = face_recognition.face_locations(
                rgb_frame
            )

            if len(locations) == 0:
                messagebox.showwarning(
                    "No Face",
                    "No face detected. Try again."
                )
                continue

            if len(locations) > 1:
                messagebox.showwarning(
                    "Multiple Faces",
                    "Only one face should be visible."
                )
                continue

            encodings = face_recognition.face_encodings(
                rgb_frame,
                locations
            )

            if len(encodings) == 0:
                messagebox.showerror(
                    "Error",
                    "Face encoding could not be created."
                )
                continue

            face_file = FACE_DIR / f"{user_id}.jpg"
            cv2.imwrite(str(face_file), frame)

            encoding_data = pickle.dumps(encodings[0])

            connection = sqlite3.connect(DATABASE_FILE)
            cursor = connection.cursor()

            cursor.execute("""
                UPDATE users
                SET face_encoding = ?
                WHERE user_id = ?
            """, (encoding_data, user_id))

            connection.commit()
            connection.close()

            camera.release()
            cv2.destroyAllWindows()

            messagebox.showinfo(
                "Success",
                "Face captured and encoding saved successfully!"
            )
            return

        elif key == ord("q"):
            break

    camera.release()
    cv2.destroyAllWindows()


def start_attendance():
    subprocess.Popen(
        [sys.executable, "attendance.py"]
    )


def attendance_history():
    window = tk.Toplevel(root)
    window.title("Attendance History")
    window.geometry("1100x600")

    tk.Label(
        window,
        text="Attendance History",
        font=("Arial", 18, "bold")
    ).pack(pady=15)

    search_frame = tk.Frame(window)
    search_frame.pack(pady=10)

    tk.Label(
        search_frame,
        text="Search:"
    ).pack(side="left")

    search_box = tk.Entry(
        search_frame,
        width=25
    )
    search_box.pack(side="left", padx=10)

    tk.Label(
        search_frame,
        text="Date:"
    ).pack(side="left")

    date_box = tk.Entry(
        search_frame,
        width=15
    )
    date_box.pack(side="left", padx=10)

    columns = (
        "ID",
        "User ID",
        "Name",
        "Department",
        "Date",
        "Time",
        "Status"
    )

    table = ttk.Treeview(
        window,
        columns=columns,
        show="headings"
    )

    for column in columns:
        table.heading(column, text=column)
        table.column(column, width=140)

    table.pack(
        fill="both",
        expand=True,
        padx=20,
        pady=10
    )

    def show_records():
        for item in table.get_children():
            table.delete(item)

        search = search_box.get().strip()
        date = date_box.get().strip()

        connection = sqlite3.connect(DATABASE_FILE)
        cursor = connection.cursor()

        query = """
            SELECT
                attendance.attendance_id,
                users.user_id,
                users.name,
                users.department,
                attendance.date,
                attendance.time,
                attendance.status
            FROM attendance
            JOIN users
            ON attendance.user_id = users.user_id
            WHERE 1=1
        """

        values = []

        if search:
            query += """
                AND (
                    users.name LIKE ?
                    OR users.user_id LIKE ?
                    OR users.department LIKE ?
                )
            """

            text = f"%{search}%"

            values.extend([
                text,
                text,
                text
            ])

        if date:
            query += " AND attendance.date = ?"
            values.append(date)

        query += """
            ORDER BY attendance.attendance_id DESC
        """

        cursor.execute(query, values)

        records = cursor.fetchall()
        connection.close()

        for record in records:
            table.insert(
                "",
                "end",
                values=record
            )

    def clear_search():
        search_box.delete(0, tk.END)
        date_box.delete(0, tk.END)
        show_records()

    tk.Button(
        search_frame,
        text="Search",
        command=show_records
    ).pack(side="left", padx=5)

    tk.Button(
        search_frame,
        text="Clear",
        command=clear_search
    ).pack(side="left", padx=5)

    show_records()


def export_to_csv():
    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            attendance.attendance_id,
            users.user_id,
            users.name,
            users.department,
            attendance.date,
            attendance.time,
            attendance.status
        FROM attendance
        JOIN users
        ON attendance.user_id = users.user_id
        ORDER BY attendance.attendance_id
    """)

    records = cursor.fetchall()
    connection.close()

    if not records:
        messagebox.showinfo(
            "Export",
            "No attendance records to export."
        )
        return

    with open(
        CSV_FILE,
        "w",
        newline="",
        encoding="utf-8"
    ) as file:

        writer = csv.writer(file)

        writer.writerow([
            "Attendance ID",
            "User ID",
            "Name",
            "Department",
            "Date",
            "Time",
            "Status"
        ])

        writer.writerows(records)

    messagebox.showinfo(
        "Export Successful",
        "Attendance exported successfully!"
    )


def refresh_dashboard():
    total, present, absent, percentage = get_dashboard_data()

    total_users_label.config(text=str(total))
    present_today_label.config(text=str(present))
    absent_label.config(text=str(absent))
    percentage_label.config(
        text=f"{percentage:.1f}%"
    )

    for item in attendance_table.get_children():
        attendance_table.delete(item)

    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            users.user_id,
            users.name,
            users.department,
            attendance.date,
            attendance.time,
            attendance.status
        FROM attendance
        JOIN users
        ON attendance.user_id = users.user_id
        ORDER BY attendance.attendance_id DESC
        LIMIT 20
    """)

    records = cursor.fetchall()
    connection.close()

    for record in records:
        attendance_table.insert(
            "",
            "end",
            values=record
        )


setup_database()

root = tk.Tk()
root.title("Smart Attendance System")
root.geometry("1200x750")

tk.Label(
    root,
    text="Smart Attendance System",
    font=("Arial", 28, "bold")
).pack(pady=(20, 5))

tk.Label(
    root,
    text="Admin Dashboard",
    font=("Arial", 18)
).pack(pady=5)

cards_frame = tk.Frame(root)
cards_frame.pack(pady=25)


def create_card(parent, title):
    frame = tk.Frame(
        parent,
        width=150,
        height=100,
        relief="solid",
        borderwidth=1
    )

    frame.pack_propagate(False)

    tk.Label(
        frame,
        text=title,
        font=("Arial", 12, "bold")
    ).pack(pady=(15, 5))

    value = tk.Label(
        frame,
        text="0",
        font=("Arial", 22, "bold")
    )

    value.pack()

    return frame, value


total_card, total_users_label = create_card(
    cards_frame,
    "Total Users"
)
total_card.grid(row=0, column=0, padx=10)

present_card, present_today_label = create_card(
    cards_frame,
    "Present Today"
)
present_card.grid(row=0, column=1, padx=10)

absent_card, absent_label = create_card(
    cards_frame,
    "Absent"
)
absent_card.grid(row=0, column=2, padx=10)

percentage_card, percentage_label = create_card(
    cards_frame,
    "Attendance %"
)
percentage_card.grid(row=0, column=3, padx=10)


button_frame = tk.Frame(root)
button_frame.pack(pady=20)

button_style = {
    "width": 20,
    "height": 2,
    "font": ("Arial", 11, "bold")
}

tk.Button(
    button_frame,
    text="REGISTER USER",
    command=register_user,
    **button_style
).grid(row=0, column=0, padx=8, pady=8)

tk.Button(
    button_frame,
    text="CAPTURE FACE",
    command=capture_face,
    **button_style
).grid(row=0, column=1, padx=8, pady=8)

tk.Button(
    button_frame,
    text="START ATTENDANCE",
    command=start_attendance,
    **button_style
).grid(row=0, column=2, padx=8, pady=8)

tk.Button(
    button_frame,
    text="ATTENDANCE HISTORY",
    command=attendance_history,
    **button_style
).grid(row=1, column=0, padx=8, pady=8)

tk.Button(
    button_frame,
    text="EXPORT CSV",
    command=export_to_csv,
    **button_style
).grid(row=1, column=1, padx=8, pady=8)

tk.Button(
    button_frame,
    text="REFRESH DASHBOARD",
    command=refresh_dashboard,
    **button_style
).grid(row=1, column=2, padx=8, pady=8)


tk.Label(
    root,
    text="Recent Attendance",
    font=("Arial", 18, "bold")
).pack(pady=(15, 10))

table_frame = tk.Frame(root)
table_frame.pack(
    fill="both",
    expand=True,
    padx=30,
    pady=(0, 30)
)

columns = (
    "ID",
    "Name",
    "Department",
    "Date",
    "Time",
    "Status"
)

attendance_table = ttk.Treeview(
    table_frame,
    columns=columns,
    show="headings",
    height=8
)

for column in columns:
    attendance_table.heading(
        column,
        text=column
    )
    attendance_table.column(
        column,
        width=180,
        anchor="center"
    )

scrollbar = ttk.Scrollbar(
    table_frame,
    orient="vertical",
    command=attendance_table.yview
)

attendance_table.configure(
    yscrollcommand=scrollbar.set
)

attendance_table.pack(
    side="left",
    fill="both",
    expand=True
)

scrollbar.pack(
    side="right",
    fill="y"
)

refresh_dashboard()

root.mainloop()