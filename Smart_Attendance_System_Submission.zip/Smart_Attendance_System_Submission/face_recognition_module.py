import sqlite3
import pickle
from pathlib import Path
import face_recognition


DATABASE_FILE = Path("data/attendance/attendance.db")
FACE_DIR = Path("data/faces")


def save_face_encoding(user_id):
    face_file = FACE_DIR / f"{user_id}.jpg"

    if not face_file.exists():
        print("Face image not found.")
        return False

    # Load face image
    image = face_recognition.load_image_file(face_file)

    # Generate face encoding
    encodings = face_recognition.face_encodings(image)

    if len(encodings) == 0:
        print("No face found in the image.")
        return False

    if len(encodings) > 1:
        print("Multiple faces found in the image.")
        return False

    face_encoding = encodings[0]

    # Convert encoding into binary data
    encoding_data = pickle.dumps(face_encoding)

    # Save encoding in database
    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute(
        """
        UPDATE users
        SET face_encoding = ?
        WHERE user_id = ?
        """,
        (encoding_data, user_id)
    )

    connection.commit()
    connection.close()

    print(f"Face encoding saved for User ID: {user_id}")
    return True


if __name__ == "__main__":
    user_id = int(input("Enter User ID: "))

    save_face_encoding(user_id)