import tkinter as tk
from tkinter import ttk
import sqlite3
from datetime import datetime
from pathlib import Path


DATABASE_FILE = Path("data/attendance/attendance.db")


def ensure_database():
    DATABASE_FILE.parent.mkdir(parents=True, exist_ok=True)

    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            department TEXT,
            face_encoding BLOB NOT NULL
        )
    """)

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            attendance_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            date TEXT NOT NULL,
            time TEXT NOT NULL,
            status TEXT NOT NULL,
            UNIQUE(user_id, date),
            FOREIGN KEY (user_id) REFERENCES users(user_id)
        )
    """)

    connection.commit()
    connection.close()


def get_dashboard_data():
    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("SELECT COUNT(*) FROM users")
    total_users = cursor.fetchone()[0]

    today = datetime.now().strftime("%Y-%m-%d")

    cursor.execute(
        "SELECT COUNT(*) FROM attendance WHERE date = ?",
        (today,)
    )
    present_today = cursor.fetchone()[0]

    absent = max(total_users - present_today, 0)

    if total_users > 0:
        percentage = (present_today / total_users) * 100
    else:
        percentage = 0

    connection.close()

    return total_users, present_today, absent, percentage


def get_recent_attendance():
    connection = sqlite3.connect(DATABASE_FILE)
    cursor = connection.cursor()

    cursor.execute("""
        SELECT
            users.user_id,
            users.name,
            attendance.date,
            attendance.time,
            attendance.status
        FROM attendance
        JOIN users
        ON attendance.user_id = users.user_id
        ORDER BY attendance.attendance_id DESC
        LIMIT 10
    """)

    records = cursor.fetchall()
    connection.close()

    return records


# Make sure database and tables exist
ensure_database()


# ---------------- GUI ----------------

root = tk.Tk()
root.title("Smart Attendance System")
root.geometry("900x600")


title = tk.Label(
    root,
    text="Smart Attendance System",
    font=("Arial", 26, "bold")
)
title.pack(pady=25)


subtitle = tk.Label(
    root,
    text="Admin Dashboard",
    font=("Arial", 18)
)
subtitle.pack(pady=5)


# Dashboard statistics

total_users, present_today, absent, percentage = get_dashboard_data()


stats_frame = tk.Frame(root)
stats_frame.pack(pady=30)


def create_card(parent, title_text, value, column):

    card = tk.Frame(
        parent,
        width=180,
        height=100,
        relief="ridge",
        borderwidth=2
    )

    card.grid(
        row=0,
        column=column,
        padx=10
    )

    card.grid_propagate(False)

    tk.Label(
        card,
        text=title_text,
        font=("Arial", 12, "bold")
    ).pack(pady=10)

    tk.Label(
        card,
        text=value,
        font=("Arial", 20, "bold")
    ).pack()


create_card(
    stats_frame,
    "Total Users",
    total_users,
    0
)

create_card(
    stats_frame,
    "Present Today",
    present_today,
    1
)

create_card(
    stats_frame,
    "Absent",
    absent,
    2
)

create_card(
    stats_frame,
    "Attendance %",
    f"{percentage:.1f}%",
    3
)


# Recent attendance

tk.Label(
    root,
    text="Recent Attendance",
    font=("Arial", 16, "bold")
).pack(pady=20)


columns = (
    "ID",
    "Name",
    "Date",
    "Time",
    "Status"
)


table = ttk.Treeview(
    root,
    columns=columns,
    show="headings",
    height=8
)


for column in columns:

    table.heading(
        column,
        text=column
    )

    table.column(
        column,
        width=140,
        anchor="center"
    )


table.pack(
    padx=30,
    fill="x"
)


# Load recent records

records = get_recent_attendance()


for record in records:

    table.insert(
        "",
        "end",
        values=record
    )


# Start GUI

root.mainloop()