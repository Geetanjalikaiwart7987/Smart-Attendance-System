# Smart Attendance System Using Face Recognition

## Project Description

Smart Attendance System is a Python-based attendance management application that uses face recognition to identify registered users and automatically record their attendance.

The system captures a user's face through a webcam, compares it with registered face data, and records the date and time when the user is recognized.

## Features

- User registration
- Face capture using webcam
- Face encoding and storage
- Face recognition
- Automatic attendance marking
- Date and time recording
- Same-day duplicate attendance prevention
- Unknown face detection
- Attendance history
- Search and filter attendance records
- Dashboard with attendance summary
- CSV attendance export
- Basic error handling

## Technology Used

- Python
- OpenCV
- Face Recognition
- NumPy
- Pandas
- SQLite
- Tkinter
- Pillow

## Project Workflow

Register User -> Capture Face -> Generate Face Encoding -> Start Attendance -> Detect Face -> Compare With Registered Faces -> Recognize User -> Mark Attendance -> Store Date and Time -> Display Attendance Record

## Project Structure

```text
Smart_Attendance_System/
|
├── app.py
├── attendance.py
├── attendance_history.py
├── database.py
├── face_capture.py
├── face_recognition_module.py
├── restore_database.py
├── requirements.txt
├── README.md
|
└── data/
    ├── attendance/
    │   ├── attendance.db
    │   └── attendance_export.csv
    |
    └── faces/